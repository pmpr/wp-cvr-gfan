<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670e55b52c7e3             |
    |_______________________________________|
*/
 pmpr_do_action("\x69\x6e\151\x74\x5f\143\x6f\x76\x65\x72");
