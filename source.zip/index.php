<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a8c2bff1             |
    |_______________________________________|
*/
 pmpr_do_action("\x69\x6e\x69\164\x5f\143\x6f\x76\145\x72");
