<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663336acece6e             |
    |_______________________________________|
*/
 pmpr_do_action("\151\x6e\x69\x74\x5f\143\x6f\x76\x65\x72");
