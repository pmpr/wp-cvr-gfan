<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800f86561607             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Asset extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu('wp', [$this, 'enqueue']); } public function enqueue() { $meakksicouekcgoe = $this->caokeucsksukesyo()->usugyumcgeaaowsi(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->goumkccmgysgqueu()) { $meakksicouekcgoe->yawoscugkyysowie($meakksicouekcgoe->awgyqswkqywwmkye($this, 'app', 'app.css')); $meakksicouekcgoe->yawoscugkyysowie($meakksicouekcgoe->owygwqwawqoiusis($this, 'app', 'app.js')->simswskycwagoeqy()); if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->takycgcamoacksqw() || $this->uwkmaywceaaaigwo()->aqasygcsqysmmyke()->kmymkocwcawgeccm()) { $meakksicouekcgoe->yawoscugkyysowie($meakksicouekcgoe->owygwqwawqoiusis($this, 'carousel', 'carousel.js')->simswskycwagoeqy()); } } $usyqkyomqcuocgoa = $this->iuygowkemiiwqmiw('inline.css', [Constants::qgqyauaqwqmqseim => $meakksicouekcgoe->eyamqkqiykagecsw(IconInterface::ckqgusoqoosqqwyo)]); $meakksicouekcgoe->yawoscugkyysowie($meakksicouekcgoe->awgyqswkqywwmkye($this, 'inline')->awagieqcmmwkgwgs($usyqkyomqcuocgoa)); } }
