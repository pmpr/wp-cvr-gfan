<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d5a9fb00c3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Component; use Pmpr\Cover\Gfan\Component\Module\Module; use Pmpr\Cover\Gfan\Container; class Component extends Container { public function mameiwsayuyquoeq() { Module::symcgieuakksimmu(); } }
