<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d42f873b7d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Component; use Pmpr\Cover\Gfan\Component\Module\Module; use Pmpr\Cover\Gfan\Container; class Component extends Container { public function mameiwsayuyquoeq() { Module::symcgieuakksimmu(); } }
