<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebde3f871             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Component; use Pmpr\Cover\Gfan\Component\Module\Module; use Pmpr\Cover\Gfan\Container; class Component extends Container { public function mameiwsayuyquoeq() { Module::symcgieuakksimmu(); } }
