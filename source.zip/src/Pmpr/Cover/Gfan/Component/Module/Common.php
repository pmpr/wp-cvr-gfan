<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11436ed0f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Component\Module; use Pmpr\Cover\Gfan\Container; abstract class Common extends Container { }
