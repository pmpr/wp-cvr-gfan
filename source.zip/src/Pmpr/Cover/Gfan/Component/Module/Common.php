<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d5a9fb00c3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Component\Module; use Pmpr\Cover\Gfan\Container; abstract class Common extends Container { }
