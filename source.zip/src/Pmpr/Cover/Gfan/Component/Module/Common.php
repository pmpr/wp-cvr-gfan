<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf71c0dfaf             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Component\Module; use Pmpr\Cover\Gfan\Container; abstract class Common extends Container { }
