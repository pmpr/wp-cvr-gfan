<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d835888a8b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Component\Module; use Pmpr\Cover\Gfan\Container; abstract class Common extends Container { }
