<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662e3789541c3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Component\Module; use Pmpr\Cover\Gfan\Container; abstract class Common extends Container { }
