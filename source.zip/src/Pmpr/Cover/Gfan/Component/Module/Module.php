<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab7d70fe5             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Component\Module; class Module extends Common { public function mameiwsayuyquoeq() { Contact::symcgieuakksimmu(); } }
