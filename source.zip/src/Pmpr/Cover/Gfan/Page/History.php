<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d404031ca8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class History extends Common { public function __construct() { $this->slug = "\150\x69\163\164\157\x72\171"; $this->title = __("\x48\151\163\x74\x6f\162\171", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
