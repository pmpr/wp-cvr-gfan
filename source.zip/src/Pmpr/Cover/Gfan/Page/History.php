<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707c34e0a3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class History extends Common { public function __construct() { $this->slug = "\x68\151\163\164\x6f\x72\171"; $this->title = __("\x48\x69\163\x74\x6f\x72\x79", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
