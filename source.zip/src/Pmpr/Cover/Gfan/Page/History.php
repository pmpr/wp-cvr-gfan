<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf71c0dfaf             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class History extends Common { public function __construct() { $this->slug = "\150\x69\163\164\157\x72\171"; $this->title = __("\110\x69\163\164\157\162\171", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
