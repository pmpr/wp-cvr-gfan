<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d8217c2176             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class History extends Common { public function __construct() { $this->slug = "\x68\x69\163\164\x6f\x72\x79"; $this->title = __("\x48\x69\x73\164\x6f\162\x79", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
