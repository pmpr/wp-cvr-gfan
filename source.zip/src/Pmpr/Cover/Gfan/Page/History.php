<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11436ed0f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class History extends Common { public function __construct() { $this->slug = "\150\151\163\164\157\x72\171"; $this->title = __("\x48\x69\x73\x74\157\162\x79", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
