<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d4ca81279c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class History extends Common { public function __construct() { $this->slug = "\150\x69\163\164\157\162\171"; $this->title = __("\110\x69\x73\x74\x6f\x72\x79", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
