<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f43994e3f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class History extends Common { public function __construct() { $this->slug = "\150\x69\x73\x74\x6f\x72\171"; $this->title = __("\x48\151\x73\164\x6f\162\171", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
