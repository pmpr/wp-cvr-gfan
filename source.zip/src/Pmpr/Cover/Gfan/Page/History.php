<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d60b24334a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class History extends Common { public function __construct() { $this->slug = "\x68\151\163\164\157\x72\171"; $this->title = __("\110\151\163\164\x6f\162\x79", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
