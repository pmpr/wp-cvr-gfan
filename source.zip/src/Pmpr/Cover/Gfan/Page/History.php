<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d8e411892c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class History extends Common { public function __construct() { $this->slug = "\150\151\163\164\x6f\162\171"; $this->title = __("\110\x69\x73\x74\157\x72\171", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
