<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663341417d110             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class History extends Common { public function __construct() { $this->slug = "\x68\151\x73\164\x6f\x72\171"; $this->title = __("\x48\151\x73\164\157\162\x79", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
