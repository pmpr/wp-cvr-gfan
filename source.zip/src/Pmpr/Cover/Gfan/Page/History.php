<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d42f873b7d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class History extends Common { public function __construct() { $this->slug = "\150\151\x73\164\x6f\x72\171"; $this->title = __("\110\x69\163\x74\x6f\x72\x79", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
