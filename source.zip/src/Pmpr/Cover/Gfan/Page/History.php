<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d5a9fb00c3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class History extends Common { public function __construct() { $this->slug = "\150\x69\x73\164\x6f\x72\x79"; $this->title = __("\110\151\x73\x74\x6f\x72\x79", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
