<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a86a64943             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class History extends Common { public function __construct() { $this->slug = "\x68\151\163\164\157\162\x79"; $this->title = __("\110\x69\163\x74\157\162\x79", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
