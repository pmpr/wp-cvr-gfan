<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662e3316a261b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class History extends Common { public function __construct() { $this->slug = "\x68\x69\163\x74\x6f\162\x79"; $this->title = __("\110\x69\x73\x74\x6f\162\171", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
