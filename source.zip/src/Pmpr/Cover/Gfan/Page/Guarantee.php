<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662e3e1ebb761             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Guarantee extends Common { public function __construct() { $this->slug = "\x67\165\x61\162\x61\156\x74\x65\145"; $this->title = __("\x47\x75\x61\x72\x61\156\164\145\145", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
