<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d901e6e3a9             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Guarantee extends Common { public function __construct() { $this->slug = "\x67\165\141\x72\x61\x6e\164\x65\x65"; $this->title = __("\x47\165\x61\162\x61\156\x74\145\x65", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
