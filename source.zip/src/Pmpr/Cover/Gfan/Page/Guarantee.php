<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684008e1a6f8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Guarantee extends Common { public function __construct() { $this->slug = "\147\x75\141\162\x61\156\x74\x65\x65"; $this->title = __("\x47\x75\141\162\141\156\164\145\145", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
