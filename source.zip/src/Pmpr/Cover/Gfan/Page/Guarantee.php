<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf889c2b3f5             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Guarantee extends Common { public function __construct() { $this->slug = "\x67\x75\x61\162\141\156\164\145\145"; $this->title = __("\x47\x75\141\x72\x61\x6e\164\x65\x65", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
