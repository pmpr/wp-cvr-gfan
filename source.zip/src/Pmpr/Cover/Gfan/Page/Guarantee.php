<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d404031ca8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Guarantee extends Common { public function __construct() { $this->slug = "\x67\x75\x61\x72\x61\156\164\145\145"; $this->title = __("\x47\165\x61\x72\x61\156\164\145\145", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
