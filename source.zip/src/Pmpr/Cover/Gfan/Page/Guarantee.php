<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d4ca81279c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Guarantee extends Common { public function __construct() { $this->slug = "\x67\x75\141\162\x61\156\x74\145\145"; $this->title = __("\107\165\141\x72\141\x6e\164\x65\145", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
