<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab7d70fe5             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Guarantee extends Common { public function __construct() { $this->slug = "\147\165\x61\x72\x61\156\x74\x65\145"; $this->title = __("\x47\165\141\162\x61\156\164\x65\x65", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
