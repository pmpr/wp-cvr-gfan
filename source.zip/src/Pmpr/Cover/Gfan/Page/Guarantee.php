<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707c34e0a3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Guarantee extends Common { public function __construct() { $this->slug = "\147\165\141\x72\x61\x6e\164\x65\145"; $this->title = __("\107\165\x61\162\141\x6e\164\145\x65", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
