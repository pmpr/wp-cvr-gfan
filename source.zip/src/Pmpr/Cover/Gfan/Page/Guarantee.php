<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce14f4527dd             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Guarantee extends Common { public function __construct() { $this->slug = "\147\x75\x61\162\141\156\x74\145\145"; $this->title = __("\x47\165\x61\x72\x61\156\164\x65\145", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
