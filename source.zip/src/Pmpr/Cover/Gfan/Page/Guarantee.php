<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a86a64943             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Guarantee extends Common { public function __construct() { $this->slug = "\x67\x75\141\x72\x61\x6e\x74\145\x65"; $this->title = __("\107\x75\141\162\141\x6e\x74\x65\145", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
