<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d37b9c961b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Guarantee extends Common { public function __construct() { $this->slug = "\x67\165\x61\162\x61\156\164\145\x65"; $this->title = __("\107\165\141\x72\141\x6e\164\145\x65", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
