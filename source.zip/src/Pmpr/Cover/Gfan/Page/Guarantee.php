<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56a61abfd             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Guarantee extends Common { public function __construct() { $this->slug = "\x67\165\141\162\x61\156\164\x65\145"; $this->title = __("\x47\x75\141\162\x61\x6e\x74\x65\x65", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
