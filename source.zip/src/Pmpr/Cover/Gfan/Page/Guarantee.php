<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d8e411892c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Guarantee extends Common { public function __construct() { $this->slug = "\x67\165\x61\x72\x61\x6e\x74\x65\145"; $this->title = __("\107\x75\x61\x72\x61\x6e\x74\x65\x65", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
