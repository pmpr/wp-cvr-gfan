<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d60b24334a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Guarantee extends Common { public function __construct() { $this->slug = "\x67\165\x61\162\x61\x6e\164\145\x65"; $this->title = __("\x47\x75\x61\x72\141\156\x74\x65\x65", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
