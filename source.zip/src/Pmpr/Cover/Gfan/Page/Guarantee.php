<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf71c0dfaf             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Guarantee extends Common { public function __construct() { $this->slug = "\x67\165\x61\162\141\156\x74\145\x65"; $this->title = __("\107\165\141\162\141\x6e\x74\x65\x65", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
