<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85e3d930             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Guarantee extends Common { public function __construct() { $this->slug = "\147\165\x61\x72\x61\156\x74\x65\x65"; $this->title = __("\107\x75\141\x72\x61\156\x74\145\145", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
