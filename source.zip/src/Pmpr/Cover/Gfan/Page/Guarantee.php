<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663341417d110             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Guarantee extends Common { public function __construct() { $this->slug = "\x67\x75\141\x72\x61\156\x74\145\145"; $this->title = __("\107\x75\x61\x72\x61\156\x74\145\x65", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
