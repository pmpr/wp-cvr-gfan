<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d8217c2176             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Guarantee extends Common { public function __construct() { $this->slug = "\147\x75\141\x72\141\156\x74\145\x65"; $this->title = __("\x47\x75\x61\162\x61\x6e\x74\145\145", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
