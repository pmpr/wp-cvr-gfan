<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebde3f871             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Shipping extends Common { public function __construct() { $this->slug = "\163\x68\x69\160\160\151\156\147"; $this->title = __("\x53\150\151\x70\x70\x69\156\147", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
