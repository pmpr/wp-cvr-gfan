<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662e3e1ebb761             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Shipping extends Common { public function __construct() { $this->slug = "\x73\x68\x69\x70\160\x69\156\x67"; $this->title = __("\123\x68\x69\160\x70\151\156\147", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
