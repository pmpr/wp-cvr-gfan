<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab7d70fe5             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Shipping extends Common { public function __construct() { $this->slug = "\x73\x68\x69\x70\160\x69\x6e\x67"; $this->title = __("\123\150\151\x70\160\x69\156\x67", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
