<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56a61abfd             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Shipping extends Common { public function __construct() { $this->slug = "\163\x68\x69\x70\160\151\156\x67"; $this->title = __("\123\150\151\160\160\151\x6e\x67", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
