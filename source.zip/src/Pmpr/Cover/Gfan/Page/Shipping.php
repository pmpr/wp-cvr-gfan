<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707c34e0a3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Shipping extends Common { public function __construct() { $this->slug = "\x73\x68\x69\160\x70\x69\x6e\x67"; $this->title = __("\x53\150\x69\160\160\151\x6e\147", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
