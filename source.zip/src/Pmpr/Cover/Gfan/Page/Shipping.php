<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d901e6e3a9             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Shipping extends Common { public function __construct() { $this->slug = "\x73\150\x69\x70\160\x69\156\147"; $this->title = __("\123\150\151\x70\x70\151\x6e\x67", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
