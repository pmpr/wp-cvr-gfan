<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f43994e3f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Shipping extends Common { public function __construct() { $this->slug = "\x73\150\x69\x70\x70\x69\x6e\x67"; $this->title = __("\123\150\151\160\x70\151\156\147", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
