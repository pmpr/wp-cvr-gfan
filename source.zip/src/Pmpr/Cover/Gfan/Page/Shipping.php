<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d60b24334a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Shipping extends Common { public function __construct() { $this->slug = "\163\150\x69\160\x70\151\x6e\147"; $this->title = __("\123\x68\151\x70\x70\x69\156\147", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
