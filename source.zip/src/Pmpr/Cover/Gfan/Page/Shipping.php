<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d4ca81279c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Shipping extends Common { public function __construct() { $this->slug = "\x73\150\x69\x70\160\x69\x6e\x67"; $this->title = __("\x53\x68\151\160\x70\151\156\x67", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
