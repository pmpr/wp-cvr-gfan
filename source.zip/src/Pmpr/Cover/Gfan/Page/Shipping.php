<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf71c0dfaf             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Shipping extends Common { public function __construct() { $this->slug = "\163\x68\x69\x70\x70\x69\156\x67"; $this->title = __("\123\150\x69\x70\160\x69\156\x67", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }
