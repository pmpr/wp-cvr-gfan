<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662e3e1ebb761             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; use Pmpr\Common\Foundation\Page\Page; abstract class Common extends Page { }
