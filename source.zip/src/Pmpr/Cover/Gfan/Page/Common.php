<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce14f4527dd             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; use Pmpr\Common\Foundation\Page\Page; abstract class Common extends Page { }
