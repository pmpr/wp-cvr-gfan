<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab7d70fe5             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; use Pmpr\Common\Foundation\Page\Page; abstract class Common extends Page { }
