<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56a61abfd             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; use Pmpr\Common\Foundation\Page\Page; abstract class Common extends Page { }
