<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d835888a8b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Whatsapp extends Common { public function __construct() { parent::__construct(__("\127\x68\x61\x74\x73\141\x70\160", PR__CVR__GFAN), __("\x44\x69\x73\x70\x6c\x61\x79\40\x74\150\x65\x20\x77\150\x61\164\163\141\x70\x70\x20\154\151\x6e\x6b\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::memskaacyikisggk)->gswweykyogmsyawy(__("\120\150\x6f\156\145", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\145\164\x5f\x63\x6f\x6e\x74\141\x63\164\x5f\x69\x6e\x66\x6f\162\155\141\x74\151\157\156", [], [self::squoamkioomemiyi => self::memskaacyikisggk])))->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\124\x65\x78\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\150\141\x74\x73\141\160\160", PR__CVR__GFAN))); } }
