<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fd592f79             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\x57\150\141\x74\x73\x61\x70\160", PR__CVR__GFAN), __("\104\x69\163\x70\154\x61\x79\40\164\x68\x65\x20\167\150\x61\164\163\x61\160\160\40\x6c\x69\156\x6b\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\x68\157\x6e\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\145\x74\137\x63\157\x6e\164\x61\143\164\x5f\x69\156\x66\x6f\162\x6d\x61\x74\151\x6f\156", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\x54\145\170\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\x57\x68\141\164\163\x61\160\160", PR__CVR__GFAN))); } }
