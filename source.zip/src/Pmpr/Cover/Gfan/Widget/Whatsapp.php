<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d8e411892c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Whatsapp extends Common { public function __construct() { parent::__construct(__("\x57\150\141\x74\163\x61\160\x70", PR__CVR__GFAN), __("\104\x69\163\x70\154\x61\x79\40\x74\x68\x65\x20\x77\150\x61\x74\x73\x61\x70\160\40\154\x69\156\153\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::memskaacyikisggk)->gswweykyogmsyawy(__("\120\150\x6f\156\145", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\145\x74\x5f\x63\157\156\x74\141\x63\164\x5f\151\x6e\x66\x6f\162\155\x61\x74\151\x6f\156", [], [self::squoamkioomemiyi => self::memskaacyikisggk])))->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\124\x65\170\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\150\141\x74\x73\x61\x70\160", PR__CVR__GFAN))); } }
