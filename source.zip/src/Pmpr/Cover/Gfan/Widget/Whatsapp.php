<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663336acece6e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Whatsapp extends Common { public function __construct() { parent::__construct(__("\127\150\141\x74\x73\x61\x70\x70", PR__CVR__GFAN), __("\104\151\x73\x70\154\141\171\x20\x74\x68\x65\40\x77\x68\141\x74\163\141\160\x70\40\x6c\151\x6e\153\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\x68\157\156\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\x67\145\x74\x5f\143\x6f\156\x74\x61\143\164\137\151\x6e\146\x6f\x72\x6d\141\x74\151\157\x6e", [], [self::squoamkioomemiyi => self::memskaacyikisggk])))->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\124\x65\170\164", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\x68\x61\164\163\x61\160\x70", PR__CVR__GFAN))); } }
