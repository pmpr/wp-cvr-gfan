<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6712b713f315a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\x57\x68\141\x74\x73\141\160\x70", PR__CVR__GFAN), __("\104\151\163\160\154\141\171\x20\164\150\145\x20\167\150\141\164\163\x61\x70\x70\x20\x6c\x69\x6e\153\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\120\150\x6f\x6e\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\x65\x74\x5f\x63\157\x6e\164\141\x63\x74\137\x69\156\x66\157\x72\x6d\141\x74\151\157\156", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\x54\x65\x78\164", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\x68\x61\164\163\141\160\x70", PR__CVR__GFAN))); } }
