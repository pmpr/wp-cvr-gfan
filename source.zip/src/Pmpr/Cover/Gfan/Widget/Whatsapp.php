<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d4ca81279c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Whatsapp extends Common { public function __construct() { parent::__construct(__("\127\150\x61\x74\x73\141\160\x70", PR__CVR__GFAN), __("\104\151\163\160\x6c\141\x79\40\164\150\145\40\167\x68\x61\164\163\x61\160\160\40\154\x69\156\x6b\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\150\x6f\156\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\x67\x65\164\x5f\x63\157\156\164\x61\143\164\137\151\156\x66\157\x72\x6d\141\x74\x69\157\x6e", [], [self::squoamkioomemiyi => self::memskaacyikisggk])))->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\124\145\170\164", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\150\141\x74\163\141\x70\x70", PR__CVR__GFAN))); } }
