<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d901e6e3a9             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Whatsapp extends Common { public function __construct() { parent::__construct(__("\x57\x68\x61\164\x73\x61\x70\160", PR__CVR__GFAN), __("\x44\x69\163\x70\154\x61\171\x20\x74\x68\145\x20\167\x68\x61\x74\163\141\160\x70\40\154\x69\x6e\153\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\x68\157\x6e\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\x65\x74\137\143\x6f\156\x74\141\143\x74\137\151\156\x66\x6f\162\x6d\x61\x74\x69\x6f\156", [], [self::squoamkioomemiyi => self::memskaacyikisggk])))->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\x54\x65\170\164", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\150\x61\x74\163\141\160\x70", PR__CVR__GFAN))); } }
