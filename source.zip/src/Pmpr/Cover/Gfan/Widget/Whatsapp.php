<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662e3e1ebb761             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Whatsapp extends Common { public function __construct() { parent::__construct(__("\127\x68\141\x74\x73\141\160\x70", PR__CVR__GFAN), __("\104\x69\163\160\154\141\171\x20\x74\x68\x65\x20\167\150\141\x74\x73\141\160\x70\x20\x6c\151\x6e\153\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\x68\x6f\156\145", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\x67\x65\x74\x5f\x63\x6f\x6e\164\141\143\x74\137\x69\x6e\146\x6f\162\155\141\x74\x69\157\156", [], [self::squoamkioomemiyi => self::memskaacyikisggk])))->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\124\x65\x78\164", PR__CVR__GFAN))->eyygsasuqmommkua(__("\x57\150\141\164\163\141\x70\160", PR__CVR__GFAN))); } }
