<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a86a64943             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Whatsapp extends Common { public function __construct() { parent::__construct(__("\x57\150\141\x74\x73\x61\160\160", PR__CVR__GFAN), __("\104\x69\163\x70\x6c\141\x79\40\x74\x68\x65\40\167\150\x61\x74\x73\141\x70\160\40\154\x69\156\153\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\150\x6f\156\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\x67\x65\x74\x5f\143\x6f\156\x74\141\x63\164\x5f\x69\x6e\146\x6f\x72\x6d\x61\x74\x69\157\156", [], [self::squoamkioomemiyi => self::memskaacyikisggk])))->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\124\145\x78\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\x57\150\x61\x74\x73\x61\x70\x70", PR__CVR__GFAN))); } }
