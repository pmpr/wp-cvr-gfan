<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf889c2b3f5             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; class Whatsapp extends Common { public function __construct() { parent::__construct(__("\x57\x68\141\164\x73\141\x70\x70", PR__CVR__GFAN), __("\x44\151\x73\x70\154\x61\x79\x20\164\x68\x65\40\167\x68\x61\164\163\x61\160\160\x20\x6c\x69\x6e\153\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\x68\157\x6e\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\x67\145\164\x5f\x63\x6f\156\164\x61\143\x74\137\151\x6e\x66\x6f\162\155\141\164\151\157\x6e", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\124\x65\x78\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\150\141\x74\163\141\160\x70", PR__CVR__GFAN))); } }
