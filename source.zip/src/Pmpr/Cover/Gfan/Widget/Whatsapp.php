<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684008e1a6f8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Whatsapp extends Common { public function __construct() { parent::__construct(__("\x57\150\x61\x74\163\x61\x70\160", PR__CVR__GFAN), __("\104\x69\163\160\154\x61\171\40\164\150\x65\x20\x77\150\141\x74\x73\141\x70\x70\40\x6c\151\156\153\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::memskaacyikisggk)->gswweykyogmsyawy(__("\120\150\157\x6e\145", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\145\x74\137\x63\x6f\x6e\164\x61\143\164\x5f\151\x6e\146\x6f\x72\x6d\x61\164\151\157\x6e", [], [self::squoamkioomemiyi => self::memskaacyikisggk])))->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\x54\x65\x78\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\x68\x61\x74\x73\x61\160\x70", PR__CVR__GFAN))); } }
