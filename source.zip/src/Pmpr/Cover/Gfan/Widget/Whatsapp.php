<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d404031ca8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Whatsapp extends Common { public function __construct() { parent::__construct(__("\127\150\141\x74\163\141\160\x70", PR__CVR__GFAN), __("\x44\151\x73\160\154\x61\x79\40\164\x68\145\40\x77\150\x61\x74\163\x61\160\160\x20\154\151\156\x6b\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\x68\x6f\x6e\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\x65\x74\137\143\157\x6e\x74\x61\x63\x74\137\151\x6e\x66\157\162\155\141\x74\x69\157\x6e", [], [self::squoamkioomemiyi => self::memskaacyikisggk])))->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\x54\145\x78\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\x68\x61\164\x73\x61\160\160", PR__CVR__GFAN))); } }
