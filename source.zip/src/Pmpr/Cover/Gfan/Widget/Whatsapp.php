<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707c34e0a3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Whatsapp extends Common { public function __construct() { parent::__construct(__("\127\150\x61\164\x73\x61\x70\160", PR__CVR__GFAN), __("\x44\x69\x73\x70\x6c\x61\x79\x20\x74\x68\145\40\x77\x68\141\164\x73\x61\x70\x70\40\x6c\x69\x6e\153\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\150\x6f\156\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\145\x74\137\143\157\156\x74\x61\x63\x74\x5f\151\156\146\157\162\155\x61\164\151\157\156", [], [self::squoamkioomemiyi => self::memskaacyikisggk])))->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\x54\x65\170\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\150\x61\164\163\141\x70\x70", PR__CVR__GFAN))); } }
