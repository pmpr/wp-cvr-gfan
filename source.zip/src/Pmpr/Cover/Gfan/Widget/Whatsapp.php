<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670e67d994c2f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\127\x68\x61\164\x73\x61\160\x70", PR__CVR__GFAN), __("\x44\x69\x73\160\154\141\171\x20\164\x68\145\x20\x77\x68\x61\x74\163\141\x70\160\40\154\151\x6e\x6b\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\x68\x6f\x6e\145", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\145\x74\x5f\143\x6f\156\164\x61\x63\164\x5f\151\x6e\146\157\x72\155\141\164\151\x6f\x6e", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\124\x65\170\164", PR__CVR__GFAN))->eyygsasuqmommkua(__("\x57\x68\x61\164\163\x61\160\x70", PR__CVR__GFAN))); } }
