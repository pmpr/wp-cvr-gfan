<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf71c0dfaf             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Whatsapp extends Common { public function __construct() { parent::__construct(__("\127\150\141\x74\x73\x61\x70\160", PR__CVR__GFAN), __("\104\151\163\x70\154\141\171\x20\x74\x68\x65\x20\x77\x68\x61\x74\x73\x61\x70\x70\40\154\x69\x6e\153\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\150\x6f\156\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\x65\164\137\143\x6f\x6e\164\x61\x63\x74\137\x69\x6e\x66\x6f\162\x6d\x61\x74\x69\x6f\156", [], [self::squoamkioomemiyi => self::memskaacyikisggk])))->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\124\x65\x78\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\x57\x68\x61\x74\163\141\160\160", PR__CVR__GFAN))); } }
