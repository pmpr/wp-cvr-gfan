<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670ed858863da             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\127\150\x61\x74\163\141\160\160", PR__CVR__GFAN), __("\x44\151\163\x70\154\x61\x79\40\x74\150\145\x20\167\x68\141\x74\x73\x61\160\160\40\154\x69\156\x6b\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\150\157\156\145", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\x65\164\137\x63\x6f\x6e\x74\x61\x63\164\x5f\151\x6e\x66\x6f\162\155\x61\164\x69\x6f\156", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\x54\x65\x78\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\x57\x68\x61\x74\163\x61\160\160", PR__CVR__GFAN))); } }
