<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670e604f28805             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\127\x68\x61\x74\x73\141\160\160", PR__CVR__GFAN), __("\x44\151\163\160\154\x61\171\x20\x74\150\x65\x20\x77\x68\141\164\x73\141\x70\x70\40\x6c\151\x6e\153\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\150\157\x6e\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\x67\145\x74\x5f\x63\157\156\x74\x61\143\x74\x5f\151\156\x66\157\162\155\x61\x74\151\x6f\156", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\124\x65\170\164", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\x68\x61\x74\x73\141\160\160", PR__CVR__GFAN))); } }
