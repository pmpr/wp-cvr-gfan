<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670db3142ce17             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\127\x68\x61\x74\x73\141\x70\x70", PR__CVR__GFAN), __("\x44\x69\x73\x70\x6c\x61\x79\40\x74\x68\145\x20\x77\150\141\x74\163\x61\160\160\x20\154\x69\156\x6b\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\x68\157\156\145", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\x65\164\x5f\x63\157\x6e\164\141\143\164\x5f\x69\x6e\146\x6f\x72\x6d\x61\x74\151\x6f\x6e", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\x54\x65\170\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\x68\x61\164\163\x61\160\x70", PR__CVR__GFAN))); } }
