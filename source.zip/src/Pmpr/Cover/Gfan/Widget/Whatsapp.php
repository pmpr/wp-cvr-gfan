<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11436ed0f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; class Whatsapp extends Common { public function __construct() { parent::__construct(__("\x57\x68\141\164\x73\141\x70\160", PR__CVR__GFAN), __("\x44\151\163\x70\x6c\141\171\40\x74\x68\x65\x20\167\150\141\x74\x73\x61\160\x70\x20\x6c\151\156\x6b\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\120\150\x6f\156\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\x67\145\164\x5f\x63\x6f\156\164\141\x63\x74\137\151\156\146\157\x72\x6d\141\164\151\157\156", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\124\145\x78\164", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\x68\141\x74\163\x61\x70\160", PR__CVR__GFAN))); } }
