<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85e3d930             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; class Whatsapp extends Common { public function __construct() { parent::__construct(__("\x57\x68\141\x74\x73\141\160\160", PR__CVR__GFAN), __("\104\x69\x73\x70\154\x61\171\x20\x74\150\145\x20\167\x68\x61\x74\163\141\x70\160\x20\x6c\151\156\153\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\150\157\156\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\145\164\137\x63\157\x6e\164\141\143\x74\137\x69\156\x66\x6f\x72\x6d\141\164\x69\x6f\x6e", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\x54\145\x78\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\x57\x68\x61\x74\x73\141\x70\x70", PR__CVR__GFAN))); } }
