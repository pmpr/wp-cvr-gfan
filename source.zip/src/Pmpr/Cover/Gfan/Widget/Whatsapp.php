<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce14f4527dd             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; class Whatsapp extends Common { public function __construct() { parent::__construct(__("\127\x68\x61\164\163\x61\x70\160", PR__CVR__GFAN), __("\104\151\x73\x70\154\141\x79\40\164\150\x65\40\x77\150\x61\x74\163\141\x70\160\40\154\151\x6e\x6b\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\150\157\156\145", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\x65\x74\x5f\x63\x6f\156\x74\141\143\x74\x5f\151\x6e\x66\157\162\x6d\x61\164\151\x6f\x6e", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\x54\145\x78\164", PR__CVR__GFAN))->eyygsasuqmommkua(__("\x57\150\141\164\x73\x61\x70\x70", PR__CVR__GFAN))); } }
