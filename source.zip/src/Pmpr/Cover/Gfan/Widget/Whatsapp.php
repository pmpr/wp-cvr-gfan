<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6ba6c7ec             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\x57\150\x61\164\163\x61\160\x70", PR__CVR__GFAN), __("\x44\151\x73\x70\x6c\141\171\x20\164\150\x65\x20\x77\x68\x61\x74\x73\x61\160\x70\40\x6c\151\156\x6b\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\120\150\157\x6e\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\145\164\x5f\143\x6f\156\x74\x61\x63\x74\137\151\156\x66\x6f\x72\x6d\141\x74\x69\157\x6e", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\x54\x65\x78\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\150\141\164\x73\x61\x70\160", PR__CVR__GFAN))); } }
