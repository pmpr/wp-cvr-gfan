<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6712ba1b122f1             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\x57\x68\141\x74\163\x61\x70\160", PR__CVR__GFAN), __("\x44\x69\163\x70\154\141\171\40\x74\150\x65\x20\x77\150\x61\164\x73\141\160\x70\x20\x6c\x69\156\153\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\150\x6f\156\145", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\x65\x74\137\143\x6f\x6e\164\x61\143\x74\137\x69\x6e\x66\x6f\162\155\x61\x74\x69\x6f\156", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\x54\x65\x78\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\x57\150\141\164\x73\141\160\160", PR__CVR__GFAN))); } }
