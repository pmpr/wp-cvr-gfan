<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6633437f834fa             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Whatsapp extends Common { public function __construct() { parent::__construct(__("\x57\150\141\x74\x73\141\160\160", PR__CVR__GFAN), __("\104\151\163\160\154\x61\x79\40\164\150\145\40\167\150\141\164\163\141\160\160\x20\154\151\x6e\x6b\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::memskaacyikisggk)->gswweykyogmsyawy(__("\120\x68\157\x6e\145", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\x67\x65\x74\137\x63\157\x6e\x74\x61\x63\164\137\151\156\146\x6f\x72\155\141\x74\x69\x6f\x6e", [], [self::squoamkioomemiyi => self::memskaacyikisggk])))->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\124\145\x78\164", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\150\141\x74\x73\x61\160\x70", PR__CVR__GFAN))); } }
