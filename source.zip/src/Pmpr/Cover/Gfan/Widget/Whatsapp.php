<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662e3789541c3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Whatsapp extends Common { public function __construct() { parent::__construct(__("\127\150\141\x74\163\141\160\160", PR__CVR__GFAN), __("\104\x69\163\160\154\141\x79\40\164\150\145\40\167\150\141\164\x73\x61\x70\x70\40\154\151\x6e\x6b\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\x68\x6f\x6e\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\x67\x65\x74\137\143\157\156\x74\x61\x63\164\x5f\x69\156\x66\157\162\155\141\164\x69\x6f\156", [], [self::squoamkioomemiyi => self::memskaacyikisggk])))->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\x54\x65\170\164", PR__CVR__GFAN))->eyygsasuqmommkua(__("\x57\150\x61\x74\163\x61\x70\x70", PR__CVR__GFAN))); } }
