<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670e55b52c7e3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\127\x68\x61\x74\163\141\160\x70", PR__CVR__GFAN), __("\104\151\163\x70\x6c\141\171\x20\164\150\145\40\x77\x68\141\x74\163\x61\x70\160\x20\x6c\151\156\x6b\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\120\x68\157\156\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\x67\x65\164\x5f\x63\x6f\156\164\141\x63\164\x5f\x69\x6e\146\157\x72\x6d\141\x74\151\157\156", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\124\145\x78\164", PR__CVR__GFAN))->eyygsasuqmommkua(__("\x57\150\141\164\x73\x61\160\160", PR__CVR__GFAN))); } }
