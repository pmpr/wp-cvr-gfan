<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d6d2006a44             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Whatsapp extends Common { public function __construct() { parent::__construct(__("\x57\x68\x61\164\x73\x61\x70\160", PR__CVR__GFAN), __("\104\151\x73\x70\154\x61\x79\x20\164\150\145\40\167\150\x61\x74\163\141\160\x70\40\154\x69\x6e\153\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\x68\x6f\156\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\x67\x65\164\x5f\143\x6f\156\164\x61\x63\x74\137\151\x6e\x66\157\x72\155\x61\x74\151\x6f\x6e", [], [self::squoamkioomemiyi => self::memskaacyikisggk])))->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\x54\145\170\164", PR__CVR__GFAN))->eyygsasuqmommkua(__("\x57\x68\141\164\x73\141\x70\160", PR__CVR__GFAN))); } }
