<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670eefd898453             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\x57\x68\141\x74\x73\x61\160\x70", PR__CVR__GFAN), __("\x44\151\163\160\154\x61\171\40\x74\150\x65\40\x77\150\141\164\163\x61\x70\160\40\154\151\156\x6b\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\120\x68\157\x6e\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\145\x74\x5f\x63\x6f\x6e\x74\141\143\164\137\x69\156\x66\157\x72\x6d\141\x74\x69\157\x6e", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\124\x65\x78\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\150\x61\x74\x73\x61\x70\160", PR__CVR__GFAN))); } }
