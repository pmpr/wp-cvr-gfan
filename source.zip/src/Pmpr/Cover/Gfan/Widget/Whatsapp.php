<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662e3316a261b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Whatsapp extends Common { public function __construct() { parent::__construct(__("\127\150\x61\x74\x73\x61\x70\x70", PR__CVR__GFAN), __("\104\x69\x73\160\154\141\171\40\x74\150\x65\40\167\150\141\x74\x73\x61\160\x70\x20\154\151\156\153\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\150\x6f\156\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\x67\145\164\x5f\x63\x6f\156\x74\141\x63\x74\137\151\x6e\146\157\162\x6d\x61\x74\x69\157\x6e", [], [self::squoamkioomemiyi => self::memskaacyikisggk])))->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\124\x65\170\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\150\x61\x74\163\x61\160\x70", PR__CVR__GFAN))); } }
