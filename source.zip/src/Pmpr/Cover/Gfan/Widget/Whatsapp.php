<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d8217c2176             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Whatsapp extends Common { public function __construct() { parent::__construct(__("\127\150\141\164\163\x61\x70\160", PR__CVR__GFAN), __("\x44\151\163\160\x6c\x61\x79\x20\x74\150\145\x20\x77\x68\x61\x74\163\x61\x70\160\40\154\x69\x6e\153\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\150\157\156\145", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\145\x74\x5f\x63\x6f\x6e\164\x61\143\164\x5f\x69\x6e\x66\157\162\x6d\x61\164\x69\x6f\156", [], [self::squoamkioomemiyi => self::memskaacyikisggk])))->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::TEXT)->gswweykyogmsyawy(__("\x54\x65\170\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\150\141\x74\163\141\x70\160", PR__CVR__GFAN))); } }
