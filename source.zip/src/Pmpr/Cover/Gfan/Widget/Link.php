<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663336acece6e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Link extends Common { public function __construct() { parent::__construct(__("\x4c\151\x6e\153\x73", PR__CVR__GFAN), __("\104\x69\x73\x70\154\x61\171\40\x74\150\145\x20\x73\145\154\145\x63\x74\145\x64\40\x6c\x69\156\153\x73\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\111\164\x65\x6d\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
