<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d901e6e3a9             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Link extends Common { public function __construct() { parent::__construct(__("\114\151\x6e\153\x73", PR__CVR__GFAN), __("\104\x69\x73\x70\154\141\x79\x20\164\x68\145\x20\x73\145\154\145\143\164\145\x64\x20\x6c\x69\156\x6b\163\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\111\164\x65\x6d\163", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
