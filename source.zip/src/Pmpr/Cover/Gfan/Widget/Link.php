<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d404031ca8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Link extends Common { public function __construct() { parent::__construct(__("\x4c\x69\x6e\x6b\x73", PR__CVR__GFAN), __("\104\x69\x73\x70\154\141\171\40\164\x68\145\x20\163\145\154\x65\143\x74\145\144\x20\154\151\156\x6b\163\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\x49\164\145\x6d\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
