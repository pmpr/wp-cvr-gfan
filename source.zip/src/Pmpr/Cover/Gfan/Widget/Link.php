<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707c34e0a3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Link extends Common { public function __construct() { parent::__construct(__("\x4c\x69\156\x6b\163", PR__CVR__GFAN), __("\104\151\x73\x70\x6c\141\171\x20\x74\x68\x65\40\163\145\x6c\x65\x63\164\145\144\40\154\x69\x6e\x6b\x73\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\111\x74\x65\155\163", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
