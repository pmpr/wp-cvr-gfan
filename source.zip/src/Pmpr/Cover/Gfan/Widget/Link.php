<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671248b7d610b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Link extends Widget { public function __construct() { parent::__construct(__("\114\x69\156\153\163", PR__CVR__GFAN), __("\104\x69\163\x70\154\x61\x79\40\164\150\145\40\x73\145\x6c\x65\143\x74\145\144\x20\x6c\151\156\x6b\163\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\x49\x74\x65\155\163", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
