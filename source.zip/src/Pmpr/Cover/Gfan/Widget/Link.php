<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf71c0dfaf             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Link extends Common { public function __construct() { parent::__construct(__("\114\x69\x6e\153\x73", PR__CVR__GFAN), __("\104\x69\x73\x70\x6c\x61\x79\x20\x74\x68\x65\40\x73\x65\x6c\x65\143\164\x65\144\x20\154\x69\156\153\163\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\111\164\x65\x6d\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
