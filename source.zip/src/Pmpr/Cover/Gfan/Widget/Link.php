<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6ba6c7ec             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Link extends Widget { public function __construct() { parent::__construct(__("\x4c\x69\156\x6b\x73", PR__CVR__GFAN), __("\104\151\x73\160\x6c\141\171\x20\x74\150\x65\x20\x73\145\154\x65\143\x74\x65\x64\x20\x6c\151\156\153\163\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\x49\164\x65\x6d\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
