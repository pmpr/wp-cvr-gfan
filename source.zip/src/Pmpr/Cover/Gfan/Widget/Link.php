<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670e55b52c7e3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Link extends Widget { public function __construct() { parent::__construct(__("\x4c\151\x6e\x6b\163", PR__CVR__GFAN), __("\x44\x69\163\160\154\141\x79\40\x74\x68\145\x20\x73\x65\x6c\145\x63\164\x65\x64\40\154\151\156\153\x73\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\x49\x74\x65\x6d\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
