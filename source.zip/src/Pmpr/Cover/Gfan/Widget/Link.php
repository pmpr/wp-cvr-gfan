<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a8c2bff1             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Link extends Widget { public function __construct() { parent::__construct(__("\114\x69\156\x6b\x73", PR__CVR__GFAN), __("\104\151\163\160\154\x61\171\40\164\150\145\40\163\145\x6c\x65\x63\164\x65\144\x20\x6c\x69\x6e\x6b\163\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\x49\164\x65\155\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
