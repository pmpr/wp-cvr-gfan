<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6633437f834fa             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Link extends Common { public function __construct() { parent::__construct(__("\x4c\x69\x6e\x6b\x73", PR__CVR__GFAN), __("\104\151\x73\160\154\141\171\x20\x74\x68\145\x20\x73\x65\x6c\145\143\x74\x65\144\x20\x6c\151\156\153\163\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\111\164\145\155\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
