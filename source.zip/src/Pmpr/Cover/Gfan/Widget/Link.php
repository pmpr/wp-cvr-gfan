<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85e3d930             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; class Link extends Common { public function __construct() { parent::__construct(__("\114\151\x6e\x6b\x73", PR__CVR__GFAN), __("\104\151\163\x70\154\x61\171\x20\164\x68\145\40\x73\x65\x6c\x65\x63\x74\145\144\x20\x6c\151\x6e\x6b\163\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\x49\164\145\x6d\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
