<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d6d2006a44             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Link extends Common { public function __construct() { parent::__construct(__("\114\x69\156\x6b\x73", PR__CVR__GFAN), __("\104\151\x73\x70\154\x61\x79\x20\x74\x68\145\40\x73\145\x6c\145\143\164\x65\144\40\154\151\x6e\153\x73\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\111\164\145\x6d\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
