<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce14f4527dd             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; class Link extends Common { public function __construct() { parent::__construct(__("\x4c\x69\x6e\x6b\163", PR__CVR__GFAN), __("\x44\x69\x73\x70\x6c\141\171\40\164\150\145\40\x73\x65\154\145\143\164\x65\x64\40\x6c\151\156\153\x73\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\x49\x74\145\155\163", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
