<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670dae91cca02             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Link extends Widget { public function __construct() { parent::__construct(__("\114\151\x6e\153\163", PR__CVR__GFAN), __("\104\151\163\160\x6c\141\171\x20\x74\150\145\40\x73\145\154\x65\x63\164\145\144\x20\x6c\151\156\153\x73\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\x49\164\145\155\163", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
