<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663341417d110             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Link extends Common { public function __construct() { parent::__construct(__("\x4c\151\x6e\153\163", PR__CVR__GFAN), __("\104\x69\x73\160\154\141\171\x20\x74\x68\x65\x20\163\x65\154\x65\143\x74\145\144\40\x6c\151\x6e\x6b\163\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\111\164\145\155\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
