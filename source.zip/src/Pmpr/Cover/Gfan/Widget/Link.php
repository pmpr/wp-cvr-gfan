<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684008e1a6f8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Link extends Common { public function __construct() { parent::__construct(__("\114\151\156\x6b\163", PR__CVR__GFAN), __("\x44\x69\x73\160\x6c\x61\171\40\164\x68\x65\40\x73\145\154\145\143\x74\x65\144\x20\x6c\151\x6e\153\x73\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\111\x74\145\155\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
