<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d42f873b7d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Link extends Common { public function __construct() { parent::__construct(__("\x4c\x69\x6e\x6b\163", PR__CVR__GFAN), __("\x44\x69\163\x70\154\141\171\40\164\x68\145\40\x73\x65\x6c\x65\x63\164\x65\144\40\154\151\156\x6b\x73\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\111\x74\x65\155\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
