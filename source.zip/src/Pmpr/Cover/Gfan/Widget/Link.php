<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662e3316a261b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Link extends Common { public function __construct() { parent::__construct(__("\x4c\151\156\x6b\x73", PR__CVR__GFAN), __("\104\151\x73\160\154\x61\171\40\164\150\x65\x20\x73\145\x6c\x65\143\164\145\x64\40\x6c\151\x6e\x6b\163\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\x49\164\x65\155\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
