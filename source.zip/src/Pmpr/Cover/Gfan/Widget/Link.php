<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d8217c2176             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Link extends Common { public function __construct() { parent::__construct(__("\x4c\151\156\x6b\x73", PR__CVR__GFAN), __("\104\x69\x73\x70\x6c\141\x79\x20\x74\x68\145\40\x73\x65\154\x65\x63\x74\x65\144\40\154\x69\x6e\x6b\x73\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\x49\164\145\x6d\163", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
