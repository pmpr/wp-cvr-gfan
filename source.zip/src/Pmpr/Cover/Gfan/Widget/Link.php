<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56a61abfd             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Link extends Common { public function __construct() { parent::__construct(__("\x4c\151\156\x6b\x73", PR__CVR__GFAN), __("\104\151\x73\x70\154\x61\x79\x20\x74\150\145\40\x73\145\x6c\x65\x63\164\x65\x64\40\154\x69\156\x6b\x73\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\111\164\145\x6d\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
