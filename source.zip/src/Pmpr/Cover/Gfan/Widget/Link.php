<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662e3789541c3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Link extends Common { public function __construct() { parent::__construct(__("\x4c\x69\x6e\x6b\x73", PR__CVR__GFAN), __("\104\x69\x73\160\x6c\141\x79\x20\164\x68\145\x20\x73\x65\x6c\145\143\x74\145\x64\x20\x6c\151\156\153\x73\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\x49\164\x65\155\163", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
