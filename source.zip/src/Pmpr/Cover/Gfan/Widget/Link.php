<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d835888a8b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Link extends Common { public function __construct() { parent::__construct(__("\x4c\x69\x6e\x6b\163", PR__CVR__GFAN), __("\104\151\163\160\154\x61\171\40\164\x68\x65\40\163\145\x6c\x65\143\164\145\x64\x20\154\x69\156\x6b\x73\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\111\x74\145\x6d\163", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
