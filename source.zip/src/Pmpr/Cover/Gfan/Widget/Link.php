<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11436ed0f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; class Link extends Common { public function __construct() { parent::__construct(__("\x4c\151\x6e\x6b\163", PR__CVR__GFAN), __("\104\x69\x73\x70\154\141\x79\x20\164\150\x65\40\x73\145\x6c\145\x63\164\x65\x64\40\x6c\151\156\153\163\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\111\x74\x65\x6d\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
