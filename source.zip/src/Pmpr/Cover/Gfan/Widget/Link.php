<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a86a64943             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Link extends Common { public function __construct() { parent::__construct(__("\x4c\151\x6e\x6b\x73", PR__CVR__GFAN), __("\x44\151\163\160\154\x61\171\40\x74\x68\145\40\x73\145\x6c\x65\143\164\x65\x64\x20\x6c\x69\156\153\x73\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\x49\x74\145\x6d\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
