<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d37b9c961b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Link extends Common { public function __construct() { parent::__construct(__("\114\151\156\153\163", PR__CVR__GFAN), __("\104\151\x73\x70\x6c\x61\x79\x20\164\x68\x65\40\x73\145\x6c\145\x63\x74\x65\x64\x20\x6c\151\156\153\163\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\x49\x74\x65\x6d\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
