<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d4ca81279c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Link extends Common { public function __construct() { parent::__construct(__("\114\x69\x6e\153\163", PR__CVR__GFAN), __("\104\x69\x73\x70\x6c\x61\x79\x20\164\x68\x65\x20\x73\x65\154\145\x63\164\x65\x64\40\154\151\156\x6b\x73\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\x49\164\145\x6d\163", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
