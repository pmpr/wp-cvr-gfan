<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662e3e1ebb761             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; class Link extends Common { public function __construct() { parent::__construct(__("\114\x69\x6e\x6b\163", PR__CVR__GFAN), __("\x44\151\163\160\154\x61\171\40\x74\150\x65\x20\x73\x65\154\145\x63\164\145\144\x20\154\151\x6e\x6b\163\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $this->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\x49\x74\x65\x6d\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }
