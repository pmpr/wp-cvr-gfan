<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab7d70fe5             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Cover\Gfan\Container; class Widget extends Container { public function mameiwsayuyquoeq() { Link::symcgieuakksimmu(); About::symcgieuakksimmu(); Company::symcgieuakksimmu(); Whatsapp::symcgieuakksimmu(); } }
