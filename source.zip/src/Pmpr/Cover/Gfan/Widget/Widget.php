<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56a61abfd             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Cover\Gfan\Container; class Widget extends Container { public function mameiwsayuyquoeq() { Link::symcgieuakksimmu(); About::symcgieuakksimmu(); Company::symcgieuakksimmu(); Whatsapp::symcgieuakksimmu(); } }
