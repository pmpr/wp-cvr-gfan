<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662e3e1ebb761             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Cover\Gfan\Container; class Widget extends Container { public function mameiwsayuyquoeq() { Link::symcgieuakksimmu(); About::symcgieuakksimmu(); Company::symcgieuakksimmu(); Whatsapp::symcgieuakksimmu(); } }
