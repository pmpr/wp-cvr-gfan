<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebde3f871             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Cover\Gfan\Container; class Widget extends Container { public function mameiwsayuyquoeq() { Link::symcgieuakksimmu(); About::symcgieuakksimmu(); Company::symcgieuakksimmu(); Whatsapp::symcgieuakksimmu(); } }
