<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf889c2b3f5             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Widget; abstract class Common extends Widget { }
