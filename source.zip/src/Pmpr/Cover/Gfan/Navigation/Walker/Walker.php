<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d8217c2176             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Navigation\Walker; use Pmpr\Common\Cover\Navigation\Walker as BaseClass; use Pmpr\Cover\Gfan\Traits\CommonTrait; class Walker extends BaseClass { use CommonTrait; }
