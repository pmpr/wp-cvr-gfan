<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11436ed0f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Navigation\Walker; use Pmpr\Common\Cover\Navigation\Walker as BaseClass; use Pmpr\Cover\Gfan\Traits\CommonTrait; class Walker extends BaseClass { use CommonTrait; }
