<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663341417d110             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Navigation\Walker; use Pmpr\Common\Cover\Navigation\Walker as BaseClass; use Pmpr\Cover\Gfan\Traits\CommonTrait; class Walker extends BaseClass { use CommonTrait; }
