<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684008e1a6f8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Navigation\Walker; use Pmpr\Common\Cover\Navigation\Walker as BaseClass; use Pmpr\Cover\Gfan\Traits\CommonTrait; class Walker extends BaseClass { use CommonTrait; }
