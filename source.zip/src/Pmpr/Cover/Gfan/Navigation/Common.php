<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d8217c2176             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Navigation; use Pmpr\Cover\Gfan\Container; abstract class Common extends Container { }
