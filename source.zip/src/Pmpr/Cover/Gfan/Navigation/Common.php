<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d404031ca8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Navigation; use Pmpr\Cover\Gfan\Container; abstract class Common extends Container { }
