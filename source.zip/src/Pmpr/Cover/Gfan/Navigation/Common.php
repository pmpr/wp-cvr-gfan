<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707c34e0a3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Navigation; use Pmpr\Cover\Gfan\Container; abstract class Common extends Container { }
