<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663341417d110             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Navigation; use Pmpr\Cover\Gfan\Container; abstract class Common extends Container { }
