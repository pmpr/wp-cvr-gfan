<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662e3e1ebb761             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Navigation; use Pmpr\Cover\Gfan\Container; abstract class Common extends Container { }
