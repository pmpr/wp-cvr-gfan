<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707c34e0a3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan; use Pmpr\Common\Cover\Customize\Customizer as BaseClass; class Customizer extends BaseClass implements CommonInterface { public function __construct() { $this->id = "\147\146\x61\156\x5f\143\165\163\x74\x6f\x6d\151\172\145\x72"; parent::__construct(); } public function yogecqociwgqoscg() { } }
