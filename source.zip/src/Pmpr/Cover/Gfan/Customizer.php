<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662e3316a261b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan; use Pmpr\Common\Cover\Customize\Customizer as BaseClass; class Customizer extends BaseClass implements CommonInterface { public function __construct() { $this->id = "\147\x66\141\156\x5f\x63\x75\163\164\x6f\155\151\172\145\x72"; parent::__construct(); } public function yogecqociwgqoscg() { } }
