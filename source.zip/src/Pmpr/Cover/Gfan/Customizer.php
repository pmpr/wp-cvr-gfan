<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663336acece6e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan; use Pmpr\Common\Cover\Customize\Customizer as BaseClass; class Customizer extends BaseClass implements CommonInterface { public function __construct() { $this->id = "\x67\x66\141\x6e\137\x63\x75\x73\x74\157\155\x69\x7a\145\x72"; parent::__construct(); } public function yogecqociwgqoscg() { } }
