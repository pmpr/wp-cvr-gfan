<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d404031ca8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan; use Pmpr\Common\Cover\Customize\Customizer as BaseClass; class Customizer extends BaseClass implements CommonInterface { public function __construct() { $this->id = "\x67\146\x61\x6e\137\x63\x75\163\x74\x6f\155\x69\x7a\145\162"; parent::__construct(); } public function yogecqociwgqoscg() { } }
