<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d8217c2176             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan; use Pmpr\Common\Cover\Customize\Customizer as BaseClass; class Customizer extends BaseClass implements CommonInterface { public function __construct() { $this->id = "\x67\146\141\x6e\137\x63\165\163\x74\157\155\x69\x7a\x65\x72"; parent::__construct(); } public function yogecqociwgqoscg() { } }
