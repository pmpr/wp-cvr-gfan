<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d901e6e3a9             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan; use Pmpr\Common\Cover\Customize\Customizer as BaseClass; class Customizer extends BaseClass implements CommonInterface { public function __construct() { $this->id = "\x67\x66\141\x6e\x5f\143\x75\x73\x74\x6f\x6d\x69\x7a\145\x72"; parent::__construct(); } public function yogecqociwgqoscg() { } }
