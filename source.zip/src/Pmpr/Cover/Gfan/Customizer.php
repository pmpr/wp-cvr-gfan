<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85e3d930             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan; use Pmpr\Common\Cover\Customizer\Customizer as BaseClass; class Customizer extends BaseClass { public function __construct() { $this->id = "\147\146\x61\156\x5f\143\165\x73\x74\x6f\x6d\151\x7a\x65\162"; parent::__construct(); } public function yogecqociwgqoscg() { } }
