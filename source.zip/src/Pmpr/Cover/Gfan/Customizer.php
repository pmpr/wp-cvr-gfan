<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6633437f834fa             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan; use Pmpr\Common\Cover\Customize\Customizer as BaseClass; class Customizer extends BaseClass implements CommonInterface { public function __construct() { $this->id = "\x67\146\141\156\x5f\x63\165\163\x74\x6f\x6d\x69\x7a\145\x72"; parent::__construct(); } public function yogecqociwgqoscg() { } }
