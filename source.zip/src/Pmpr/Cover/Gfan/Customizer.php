<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d852c453b1             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan; use Pmpr\Common\Cover\Customize\Customizer as BaseClass; class Customizer extends BaseClass implements CommonInterface { public function __construct() { $this->id = "\147\x66\141\x6e\137\x63\165\163\164\157\x6d\151\172\145\162"; parent::__construct(); } public function yogecqociwgqoscg() { } }
