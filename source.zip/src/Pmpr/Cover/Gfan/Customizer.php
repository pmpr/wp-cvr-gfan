<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab7d70fe5             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan; use Pmpr\Common\Cover\Customize\Customizer as BaseClass; class Customizer extends BaseClass implements CommonInterface { public function __construct() { $this->id = "\x67\x66\x61\x6e\x5f\143\x75\163\x74\157\x6d\151\172\x65\162"; parent::__construct(); } public function yogecqociwgqoscg() { } }
