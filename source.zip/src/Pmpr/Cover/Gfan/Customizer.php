<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684008e1a6f8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan; use Pmpr\Common\Cover\Customize\Customizer as BaseClass; class Customizer extends BaseClass implements CommonInterface { public function __construct() { $this->id = "\x67\146\x61\156\137\143\x75\x73\164\x6f\x6d\x69\172\x65\x72"; parent::__construct(); } public function yogecqociwgqoscg() { } }
