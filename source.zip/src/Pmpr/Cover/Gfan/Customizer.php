<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf889c2b3f5             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan; use Pmpr\Common\Cover\Customize\Customizer as BaseClass; class Customizer extends BaseClass { public function __construct() { $this->id = "\x67\x66\141\x6e\x5f\143\165\x73\164\x6f\155\x69\172\x65\162"; parent::__construct(); } public function yogecqociwgqoscg() { } }
