<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663336acece6e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Woocommerce; use Pmpr\Cover\Gfan\Container; abstract class Common extends Container { }
