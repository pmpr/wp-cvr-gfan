<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56a61abfd             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Woocommerce; use Pmpr\Cover\Gfan\Container; abstract class Common extends Container { }
