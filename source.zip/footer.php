<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56a61abfd             |
    |_______________________________________|
*/
 pmpr_do_action("\x72\x65\x6e\144\x65\162\x5f\x66\x6f\x6f\x74\x65\x72");
