<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf71c0dfaf             |
    |_______________________________________|
*/
 pmpr_do_action("\x72\145\x6e\x64\145\x72\x5f\x66\x6f\x6f\164\145\x72");
